<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp;
use Illuminate\Support\Facades\Storage;

class WapingController extends Controller
{
    public function send()
    {
        echo "hola b";
    }
}
