<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correo</title>
</head>

<body style="margin: 0; padding: 0;">
    <table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border-collapse: collapse; margin-top: 20px; border: 1px solid #aca9a9;">
        <tr>
            <td align="center" style="padding: 10px 0 8px 0;">
                <img src="https://scontent.frex1-1.fna.fbcdn.net/v/l/t1.0-9/120955114_199472874912012_5722147267701018935_n.jpg?_nc_cat=102&ccb=2&_nc_sid=09cbfe&_nc_eui2=AeGb7S7IR7ki8Ke0FW5objOw07KwOKBS-PrTsrA4oFL4-vU-DHiqaVnZLF-LLGrihkeya1s2bP3CnZO8HRSdlyY7&_nc_ohc=1eLGi5GLrw8AX-8qiwX&_nc_ht=scontent.frex1-1.fna&oh=ca67f8453f6db632e677a8d528c2c8a0&oe=6002FD4C" alt="Logo Email" width="500" height="350" style="display: block;">
            </td>
        </tr>
        <tr>
            <td bgcolor="#ffffff" style="padding: 40px 30px 40px 30px;">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td style="color: #000000; font-family: Arial, sans-serif; font-size: 18px;">
                            <?php echo $nombre; ?> <br/> <?php echo $telefono; ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 20px 0 30px 0; color: #153643; font-family: Arial, sans-serif; font-size: 18px; line-height: 20px;">
                            <?php echo "Solicitó la cantidad de: " . "<strong>" . $cantidad . "</strong>" . " del producto: "  . "<strong>" . $producto_solicitar . "</strong>";?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php echo "Requiere que su producto tenga las siguientes especificaciones " . "<strong>" . $especificar_producto . "</strong>";?>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td bgcolor="#000000" style="padding: 30px 30px 30px 30px;">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td width="75%" style="color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;">
                            &reg; Borrado's Brochet 2020.<br> Todos los derechos reservados.
                        </td>
                        <td>

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>